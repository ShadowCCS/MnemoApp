#!/usr/bin/env python3
"""
Lossless SVG Optimizer using Scour
Optimizes all SVG files in the same directory as this script.
Requires the 'scour' library for SVG optimization.
"""

import os
import sys
from pathlib import Path

def check_scour_availability():
    """Check if scour library is available and exit if not."""
    try:
        import scour
        return True
    except ImportError:
        print("ERROR: Scour library is required but not found!")
        print("Please install it using: pip install scour")
        print("Scour is a professional SVG optimizer that ensures lossless compression.")
        sys.exit(1)

def optimize_svg_with_scour(svg_content):
    """Optimize SVG content using scour library."""
    from scour import scour
    
    # Scour options for lossless optimization
    options = scour.parse_args([
        '--enable-viewboxing',
        '--enable-id-stripping',
        '--enable-comment-stripping',
        '--shorten-ids',
        '--indent=none',
        '--no-line-breaks',
        '--strip-xml-prolog',
        '--remove-metadata'
    ])
    
    # Apply scour optimization
    optimized = scour.scourString(svg_content, options)
    return optimized

def optimize_svg_file(file_path):
    """Optimize a single SVG file using scour."""
    try:
        # Read the original file
        with open(file_path, 'r', encoding='utf-8') as f:
            original_content = f.read()
        
        original_size = len(original_content)
        
        # Optimize with scour
        optimized_content = optimize_svg_with_scour(original_content)
        
        # Only write if there's an improvement or change
        if optimized_content != original_content:
            # Write optimized content back to the same file
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(optimized_content)
            
            new_size = len(optimized_content)
            size_reduction = original_size - new_size
            reduction_percent = (size_reduction / original_size) * 100 if original_size > 0 else 0
            
            print(f"✓ {file_path.name}: {original_size} → {new_size} bytes "
                  f"(-{size_reduction} bytes, -{reduction_percent:.1f}%)")
            
            return True, size_reduction
        else:
            print(f"• {file_path.name}: Already optimized")
            return False, 0
            
    except Exception as e:
        print(f"✗ Error optimizing {file_path.name}: {e}")
        return False, 0

def main():
    """Main function to optimize all SVG files in the script's directory."""
    # Check if scour is available before proceeding
    check_scour_availability()
    
    script_dir = Path(__file__).parent
    svg_files = list(script_dir.glob("*.svg"))
    
    if not svg_files:
        print("No SVG files found in the current directory.")
        return
    
    print(f"Found {len(svg_files)} SVG file(s) to optimize using Scour...")
    print("-" * 60)
    
    total_optimized = 0
    total_size_saved = 0
    
    for svg_file in sorted(svg_files):
        was_optimized, size_saved = optimize_svg_file(svg_file)
        if was_optimized:
            total_optimized += 1
            total_size_saved += size_saved
    
    print("-" * 60)
    print(f"Optimization complete!")
    print(f"Files optimized: {total_optimized}/{len(svg_files)}")
    
    if total_size_saved > 0:
        print(f"Total size saved: {total_size_saved} bytes ({total_size_saved/1024:.1f} KB)")
    
    if total_optimized == 0:
        print("All files were already optimized or no improvements could be made.")

if __name__ == "__main__":
    main()